// Homework-3
// Chinmay Chinara
// USC ID: 2527237452
// Date: 6th October 2017
----------------------------------------------------------------------
1. csci677_hw3_sift.py file has the code
2. In the code two comments 'line 5'and 'line 6' are given. Just change the name of the detection and target images
for checking different results in those two lines
5. All the code was built in Python 35 with OpenCV 3.2 and IDE being PyCharm
----------------------------------------------------------------------