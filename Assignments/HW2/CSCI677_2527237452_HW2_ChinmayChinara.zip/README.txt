// Homework-2
// Chinmay Chinara
// USC ID: 2527237452
// Date: 26th September 2017
----------------------------------------------------------------------
1. csci677_hw2_q1.py file has the code for Part-a
2. csci677_hw2_q2_m1.py file has the code for Part-b using OpenCV code from source in question
3. csci677_hw2_q2_m2.py file has the code for Part-b using marker initilization based on windowing
4. csci677_hw2_q2_m3.py file has the code for Part-b using maeker initialization based on mouse double clicks over the input image
5. All the code was built in Python 35 with OpenCV 3.2 and IDE being PyCharm
----------------------------------------------------------------------